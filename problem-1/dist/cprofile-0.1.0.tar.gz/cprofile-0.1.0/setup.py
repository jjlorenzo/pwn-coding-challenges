# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['cprofile']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['cprofile = cprofile.__main__:entry_point']}

setup_kwargs = {
    'name': 'cprofile',
    'version': '0.1.0',
    'description': '',
    'long_description': '## Problem 1\n\nProvide some Python code that can be used to measure how long some code took to run in a\nfriendly format. The amount of time can range from less than a second to several hours and\nshould be easy for a human to read (for example “193048.231s” is not a good output).\n\n## Solution\n\nThe solution is an installable python package. It has both a Command-Line Interface as well as a callable one.\n\n#### Command-Line Interface\n\n```shell\n$ pip install problem-1/dist/cprofile-0.1.0.tar.gz\n\n\n$ cprofile -h\nusage: cprofile [-h] [-v] statements [statements ...]\n\npositional arguments:\n  statements\n\noptional arguments:\n  -h, --help  show this help message and exit\n  -v\n\n\n$ cprofile "import time" "time.sleep(2)"\nExecution time: 2 seconds and 3975 microseconds\n\n\n# using the -v cli flag\n$ cprofile "import time" "time.sleep(2)" -v\nDEBUG:cprofile:code [\'import time\', \'time.sleep(2)\']\nDEBUG:cprofile:duration 0:00:02.002211\nExecution time: 2 seconds and 2210 microseconds\n```\n\n#### Python API\n\n```python\nfrom cprofile import Timer\nfrom foo.bar.baz import code_to_measure_time\n\nwith Timer() as timer:\n  code_to_measure_time()\nprint(timer.duration)\n```\n\n#### Test suite\n\nFor now, I have decided to cover only the `humanize_timedelta_duration` function, mostly because the rest is glue-code:\n\n- A Timer class that implements the Context-Manager protocol interface\n- A cli entry_point using argparse\n\nIn any case, for a production code a test-suite that complete the coverage is important.\n\n#### Dist\n\nI have included the source and binary build in the `dist` folder to ease the testing and installation.\n\n## Caveats\n\n- For geetting accurate values, the timing should disable temporarily the garbage collection, with something like:\n\n  ```python\n  import gc\n  \n  gc.isenabled()  # get current value (Timer.__init__)\n  \n  gc.disable()    # disable the gc before timing (Timer.__enter__)\n  \n  ### ...code to measure execution time...\n  \n  gc.enable()     # enable the gc after timing (Timer.__exit__)\n  ```\n\n- The conversion from a duration `timedelta` to a friendly `str` representation is prone to floating point arithmetic errors. Usually the `decimal` module is used when an exact decimal representation is required, but I don\'t feel it was required for this exercise.\n\n',
    'author': 'jjlorenzo',
    'author_email': 'jjlorenzo@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
